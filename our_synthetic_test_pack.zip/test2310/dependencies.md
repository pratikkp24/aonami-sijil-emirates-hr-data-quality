# Dependencies
Synthetic sample for the prototype.

## Feeds
| From | To | Fields | Frequency |
|---|---|---|---|
| CORE | PAYROLL | name, date of birth, hire date, status, grade, cost centre | daily |
| CORE | LEARNING | name, email, job code, department, location | daily (department within 30 days) |
| CORE | ACCESS | name, email, status, department, manager | daily |
| PAYROLL | General Ledger | cost centre, basic salary | monthly |

## Reports
| Report | Audience | Uses fields | Systems | Weight |
|---|---|---|---|---|
| Monthly payroll run | Payroll, Finance | status, basic salary, grade, cost centre | PAYROLL | 5 |
| WPS salary file | Regulator (MOHRE) | name, date of birth, basic salary, status | PAYROLL | 5 |
| Nationalisation report | Regulator, Leadership | nationality, status, grade | CORE | 5 |
| Leadership headcount dashboard | Leadership | status, department, location, grade, job code | CORE | 4 |
| Quarterly access review | Information Security | status, manager, department | ACCESS, CORE | 4 |
| Cost centre budget report | Finance | cost centre, basic salary | PAYROLL, General Ledger | 3 |
| Mandatory training compliance | Learning, Audit | job code, department, status | LEARNING | 3 |
| Attrition analytics | HR Analytics | hire date, termination date, status | CORE | 3 |
