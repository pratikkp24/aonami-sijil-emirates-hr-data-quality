# Data dictionary
Synthetic sample for the prototype. Core HR is the system of record for identity, employment and organisation fields; Payroll is the system of record for pay.

## Systems
| System | File | Key | Notes |
|---|---|---|---|
| CORE | core_hr.csv | employee_id (EK + 6 digits) | Main HR system, system of record for people |
| PAYROLL | payroll.csv | payroll_no (P + 7 digits); staff_ref holds the core number without the EK prefix | Dates DD/MM/YYYY; name as "LAST, First"; grade as a number |
| LEARNING | learning.csv | learner_id (L-5 digits); joined to people by email | Department held as a name; job code without the dash |
| ACCESS | access_directory.csv | upn; employee_number holds the core ID for employees | Includes contractors and service accounts, which have no employee number |

## Fields
| Field | CORE | PAYROLL | LEARNING | ACCESS | System of record | Required |
|---|---|---|---|---|---|---|
| Name | first_name, last_name | employee_name | display_name | display_name | CORE | yes |
| Date of birth | date_of_birth | birth_date | | | CORE | yes |
| Nationality | nationality | | | | CORE | yes |
| Hire date | hire_date | date_joined | | | CORE | yes |
| Termination date | termination_date | | | | CORE | when terminated |
| Status | employment_status | pay_status | | account_enabled | CORE | yes |
| Job code | job_code | | job_code | | CORE | yes |
| Department | department_code | | department | department | CORE | yes |
| Location | location_code | | location | | CORE | yes |
| Grade | grade | pay_grade | | | CORE | yes |
| Manager | manager_id | | | manager_upn | CORE | yes, except the CEO |
| Cost centre | cost_centre | cost_center | | | PAYROLL | yes |
| Email | work_email | | email | upn | CORE | yes |
| Basic salary | | basic_salary_aed | | | PAYROLL | yes |

## Valid codes
### Status
Active, On Leave, Terminated (CORE); ACTIVE, STOPPED (PAYROLL); TRUE, FALSE (ACCESS account_enabled)

### Grades
G01 to G15 (CORE); 1 to 15 (PAYROLL)

### Job codes
| Code | Title |
|---|---|
| JC-1001 | Cabin Crew Member |
| JC-1002 | Senior Cabin Crew |
| JC-1010 | Customer Service Agent |
| JC-1011 | Customer Service Supervisor |
| JC-1020 | Aircraft Technician |
| JC-1021 | Licensed Engineer |
| JC-1030 | Cargo Officer |
| JC-1040 | Finance Analyst |
| JC-1041 | Accountant |
| JC-1050 | Software Engineer |
| JC-1051 | IT Support Specialist |
| JC-1060 | HR Officer |
| JC-1061 | HR Business Partner |
| JC-1070 | Sales Executive |
| JC-1080 | Catering Supervisor |
| JC-1090 | Flight Dispatcher |
| JC-1100 | Manager |
| JC-1101 | Senior Manager |

### Department codes
| Code | Name |
|---|---|
| D-CC | Cabin Crew |
| D-AS | Airport Services |
| D-ENG | Engineering |
| D-CGO | Cargo |
| D-FIN | Finance |
| D-IT | Information Technology |
| D-HR | Human Resources |
| D-COM | Commercial |
| D-CAT | Catering |
| D-OPS | Flight Operations |

### Location codes
| Code | City |
|---|---|
| DXB | Dubai |
| AUH | Abu Dhabi |
| SHJ | Sharjah |
| LHR | London |
| BOM | Mumbai |
| MNL | Manila |
| CAI | Cairo |

### Nationality codes
| Code | Country |
|---|---|
| ARE | United Arab Emirates |
| IND | India |
| PHL | Philippines |
| GBR | United Kingdom |
| EGY | Egypt |
| PAK | Pakistan |
| JOR | Jordan |
| LKA | Sri Lanka |
| ZAF | South Africa |
| KEN | Kenya |

### Cost centres
CC4001 to CC4010, one per department in the order listed above (PAYROLL holds the number without the CC prefix)

## Sync rules
Changes in CORE reach PAYROLL, LEARNING and ACCESS within 1 day, except department moves, which LEARNING picks up within 30 days.
